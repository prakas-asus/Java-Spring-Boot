package com.project01.buildDIY;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuildDiyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuildDiyApplication.class, args);
	}

}
