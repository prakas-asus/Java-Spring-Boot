package com.project01.buildDIY;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuildDiyApplicationTests {

	@Test
	void contextLoads() {
	}

}
